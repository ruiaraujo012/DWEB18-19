Para importar os dados, usar o comando:
    $ mongoimport --db comps --collection comps --file compositores.json --jsonArray

O ficheiro em json encontra-se na raiz do projeto dentro da pasta json