// controllers/api/compositor
var Compositor = require('../../models/comp')

const Compositores = module.exports

//Listar todos os compositores
Compositores.listarTodos = () => {
    return Compositor
        .find({},{compID:1, nome:1, dataNasc:1})
        .exec()
}

//Listar um compositor pelo ID
Compositores.listarID = cid => {
    return Compositor
        .findOne({compID: cid})
        .exec()
}


//Listar todos os compositores por periodo
Compositores.listarTodosPeriodo = p => {
    return Compositor
        .find({periodo: p})
        .exec()
}

Compositores.listarTodosDataPeriodo = (d, p) => {
    return Compositor
        .find({dataNasc: {$gt: d }, periodo: p})
        .exec()
}
/*
//Listar todos os eventos a partir da data
Eventos.listarTodosData = data => {
    return Evento
        .find({data: {$gte: data}})
        .sort({data: -1})
        .exec()
}

//Inserir um evento
Eventos.inserir = evento =>{
    return Evento.create(evento)
}

//Editar um evento

//Eliminar um evento
*/