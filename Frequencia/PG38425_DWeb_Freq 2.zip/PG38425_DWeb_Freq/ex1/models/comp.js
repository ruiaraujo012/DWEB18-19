// models/compositor
var mongoose = require('mongoose')
var Schema = mongoose.Schema

var CompSchema = new Schema({
    obraID: {
        type: String
    },
    nome: {
        type: String
    },
    bio: {
        type: String
    },
    dataNasc: {
        type: String
    },
    dataObito: {
        type: String
    },
    periodo: {
        type: String
    }

})

var CompModel = mongoose.model('comp', CompSchema)

module.exports = CompModel