// routes/api/compositores
var express = require('express')
var router = express.Router()
var Compositor = require('../../controllers/api/comp')

// GET /
router.get('/', (req, res) => {
    let query = req.query
    if (query) {
        if (query.data && query.periodo) {
            Compositor.listarTodosDataPeriodo(query.data, query.periodo)
                .then(dados => {
                    if (dados.length == 0) res.send('Não existem compositores os dados fornecidos.')
                    else res.jsonp(dados)
                })
                .catch(erro => res.status(500).send('Erro na listagem de todos os compositores os dados fornecidos.'))
        } else if (query.periodo) {
            Compositor.listarTodosPeriodo(query.periodo)
                .then(dados => {
                    if (dados.length == 0) res.send('Não existem compositores com o periodo [' + query.periodo + '].')
                    else res.jsonp(dados)
                })
                .catch(erro => res.status(500).send('Erro na listagem de todos os compositores pelo com periodo.'))
        }
    } else {
        Compositor.listarTodos()
            .then(dados => {
                if (dados.length == 0) res.send('Não existem compositores.')
                else res.jsonp(dados)
            })
            .catch(erro => res.status(500).send('Erro na listagem de todos os compositores.'))
    }
})

// GET /:cid

router.get('/:cid', (req, res) => {
    let cid = req.params.cid
    Compositor.listarID(cid)
        .then(dados => {
            if (dados.length == 0) res.send('Não existe nenhum compositor com o id ' + eid + '.')
            else res.jsonp(dados)
        })
        .catch(erro => res.status(500).send('Erro na listagem do evento.'))
})

// GET ?periodo=XXXXX

router.get('/', (req, res) => {
    let periodo = req.query
    Evento.listarTodosTipo(et)
        .then(dados => {
            if (dados.length == 0) res.send('Não existem eventos com o tipo ' + et + '.')
            else res.jsonp(dados)
        })
        .catch(erro => res.status(500).send('Erro na listagem do evento por tipo'))
})
module.exports = router