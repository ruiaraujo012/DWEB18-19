var express = require('express')
var router = express.Router()
var axios = require('axios')

/* GET home page. */
router.get('/', (req, res, next) => {
  axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/1')
    .then(resposta => res.render('index', {
      lista: resposta.data
    }))
    .catch(erro => {
      console.log('Erro ao carregar dados.')
      res.render('error', {
        error: erro,
        message: "Erro ao carregar dados."
      })
    })
})

function getClasse(c) {
  return axios.get('http://clav-test.di.uminho.pt/api/classes/' + c);
}

function getClasseDescendencia(c) {
  return axios.get('http://clav-test.di.uminho.pt/api/classes/' + c + '/descendencia')
}

router.get('/:c', (req, res, next) => {
  axios.all([getClasse(req.params.c), getClasseDescendencia(req.params.c)])
    .then(axios.spread((classe, subclasse) => {
      res.render('classes', {
        classe: classe.data,
        subclasse: subclasse.data
      })
    }))
    .catch(erro => {
      console.log('Erro ao carregar dados.')
      res.render('error', {
        error: erro,
        message: "Erro ao carregar dados."
      })
    })
})

module.exports = router